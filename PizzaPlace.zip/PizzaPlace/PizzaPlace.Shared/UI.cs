namespace PizzaPlace.Shared
{
    public class UI 
    {
        public bool ShowBasket { get; set; } = true;
    }
}